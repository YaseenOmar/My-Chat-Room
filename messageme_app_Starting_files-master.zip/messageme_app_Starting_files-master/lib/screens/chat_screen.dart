import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
final _fireStore=FirebaseFirestore.instance;
late User signedInUser;// give email

class ChatScreen extends StatefulWidget {
  static const String secreenRoute ='chat_screen';
  const ChatScreen({Key? key}) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final massageTextcontroller=TextEditingController();

  final _auth =FirebaseAuth.instance;

  String? massageText;// give massage
  @override
  void initState(){

    super.initState();
    getCurrentUser();
  }
  void getCurrentUser(){
    final user=_auth.currentUser;

    try{ if(user !=null){
      signedInUser=user;
    }}
    catch(e){print(signedInUser.email);}
  }
  // void getMassages() async{
  //   final massages= await _fireStore.collection('massages').get();
  //   for(var massge  in massages.docs){
  //     print(massge.data());
  //   }
  // }
  void massagesStreams() async {
     await for(  var snapshot in _fireStore.collection('massages').snapshots()){
       for ( var massage in snapshot.docs){
         print(massage.data());

       }
     }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow[900],
        title: Row(
          children: [
            Image.asset('images/logo.png', height: 25),
            SizedBox(width: 10),
            Text('MessageMe')
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {
              _auth.signOut();
              Navigator.pop(context);
              // add here logout function
            },
            icon: Icon(Icons.close),
          )
        ],
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            massagStreambuilder(),

            Container(
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(
                    color: Colors.orange,
                    width: 2,
                  ),
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [

                  Expanded(
                    child: TextField(
                      controller: massageTextcontroller,
                      onChanged: (value) {

                        massageText=value;

                      },
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.symmetric(
                          vertical: 10,
                          horizontal: 20,
                        ),
                        hintText: 'Write your message here...',
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      massageTextcontroller.clear();
                      _fireStore.collection('massages').add({'text':massageText,'sender':signedInUser.email,'time':FieldValue.serverTimestamp()});
                    },
                    child: Text(
                      'send',
                      style: TextStyle(
                        color: Colors.blue[800],
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class massagStreambuilder extends StatelessWidget {
  const massagStreambuilder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
        stream: _fireStore.collection('massages').orderBy('time').snapshots(),
        builder: (context ,snapshot){
          List<masageline> massageWidgets=[];
          if(!snapshot.hasData){

            return Center(
              child: CircularProgressIndicator(
                backgroundColor: Colors.blue,
              ),
            );
          }
          final massages =snapshot.data!.docs.reversed;
          for(var massage in massages){
            final massageText=massage.get('text');
            final massagesender=massage.get('sender');
            final currentUser=signedInUser.email;

            final massageWidget = masageline(sender: massagesender,text: massageText,isMe:currentUser==massagesender) ;
            massageWidgets.add(massageWidget);

          }
          return Expanded(
            child: ListView(
              reverse: true,
              padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 20),
              children: massageWidgets,
            ),
          );
        });
  }
}

class masageline extends StatelessWidget {
  const masageline({ this.text,this.sender,required this.isMe,Key? key}) : super(key: key);
  final String? sender;
  final String? text;
  final bool  isMe;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        crossAxisAlignment: isMe? CrossAxisAlignment.end: CrossAxisAlignment.start,

        children: [
          Text('$sender',style: TextStyle(fontSize: 12,color: Colors.black45),),
          Material(
            elevation: 5,
            borderRadius:  isMe? BorderRadius.only( topLeft: Radius.circular(30),
                bottomLeft: Radius.circular(30)
                ,bottomRight: Radius.circular(30)):BorderRadius.only( topRight: Radius.circular(30),
                bottomLeft: Radius.circular(30)
                ,bottomRight: Radius.circular(30)),
              color: isMe? Colors.blue[800] :Colors.white,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 20),
                child: Text('$text ',style: TextStyle(fontSize: 15,color: isMe? Colors.white:Colors.black),),
              )),
        ],
      ),
    );
  }
}

